# Ingresia MVP

Prototipo web de una app que ayuda a convertir recursos/habilidades en oportunidades de ingresos online.

## Probarlo
Abre `index.html` en un navegador.

## Siguiente fase
1. Conectar un modelo de IA mediante backend seguro.
2. Añadir cuentas de usuario y base de datos.
3. Integrar Stripe para suscripciones.
4. Añadir generadores reales de anuncios, productos digitales y contenido.
5. Medir conversión del plan gratuito a PRO.
